const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
  event: { type: mongoose.Schema.Types.ObjectId, ref: 'Event' },
  buyerEmail: String,
  qrCode: String,
  status: { type: String, default: 'paid' },
  paymentId: String
});

module.exports = mongoose.model('Ticket', ticketSchema);

