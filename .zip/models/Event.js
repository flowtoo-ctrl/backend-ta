const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  date: { type: Date, required: true },
  location: String,
  price: { type: Number, required: true },
  ticketsAvailable: { type: Number, required: true },
  initialTickets: { type: Number, required: true }, // for calculating sold
  organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
});

module.exports = mongoose.model('Event', eventSchema);

