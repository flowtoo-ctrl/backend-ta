const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const Ticket = require('../models/Ticket');

router.get('/my', authMiddleware, async (req, res) => {
  try {
    const tickets = await Ticket.find({ buyerEmail: req.user.email }).populate('event');
    res.json(tickets);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

