const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const authMiddleware = require('../middleware/auth');

// Public: Get upcoming events
router.get('/', async (req, res) => {
  try {
    const events = await Event.find({ date: { $gte: new Date() } }).sort({ date: 1 });
    res.json(events);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Auth: Create event
router.post('/', authMiddleware, async (req, res) => {
  try {
    const eventData = {
      ...req.body,
      organizer: req.user.id,
      initialTickets: req.body.ticketsAvailable
    };
    const event = new Event(eventData);
    await event.save();
    res.status(201).json(event);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Auth: Get my events
router.get('/my', authMiddleware, async (req, res) => {
  try {
    const events = await Event.find({ organizer: req.user.id }).sort({ date: 1 });
    res.json(events);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Auth: Update tickets available
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event || event.organizer.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    event.ticketsAvailable = req.body.ticketsAvailable;
    await event.save();
    res.json(event);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;