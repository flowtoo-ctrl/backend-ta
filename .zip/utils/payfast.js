const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const axios = require("axios");
const QRCode = require("qrcode");
const nodemailer = require("nodemailer");
const Event = require("../models/Event");
const Ticket = require("../models/Ticket");

/* =========================
   PAYFAST SIGNATURE FUNCTION
========================= */
function generateSignature(data, passphrase) {
  const keys = Object.keys(data)
    .filter(
      (k) =>
        data[k] !== "" &&
        data[k] !== null &&
        data[k] !== undefined &&
        k !== "signature"
    )
    .sort();

  let pfParamString = "";

  keys.forEach((key, index) => {
    let value = data[key].toString().trim();
    value = encodeURIComponent(value).replace(/%20/g, "+");
    pfParamString += `${key}=${value}`;
    if (index < keys.length - 1) pfParamString += "&";
  });

  if (passphrase && passphrase.trim() !== "") {
    pfParamString += `&passphrase=${encodeURIComponent(
      passphrase.trim()
    ).replace(/%20/g, "+")}`;
  }

  return crypto.createHash("md5").update(pfParamString).digest("hex");
}

/* =========================
   BUY
========================= */
router.post("/buy", async (req, res) => {
  const { eventId, email } = req.body;

  try {
    const event = await Event.findById(eventId);
    if (!event || event.ticketsAvailable <= 0) {
      return res.status(400).json({ error: "Event not available or sold out" });
    }

    const pfData = {
      merchant_id: process.env.PAYFAST_MERCHANT_ID,
      merchant_key: process.env.PAYFAST_MERCHANT_KEY,
      return_url: process.env.PAYFAST_RETURN_URL,
      cancel_url: process.env.PAYFAST_CANCEL_URL,
      notify_url: process.env.PAYFAST_NOTIFY_URL,
      name_first: "Customer",
      email_address: email.trim(),
      m_payment_id: `evt-${eventId}-${Date.now()}`,
      amount: Number(event.price).toFixed(2),
      item_name: `Ticket for ${event.title}`.trim(),
      item_description: (event.description || "Event ticket").trim(),
      custom_str1: eventId.toString(),
      custom_str2: email.trim(),
    };

    pfData.signature = generateSignature(
      pfData,
      process.env.PAYFAST_PASSPHRASE
    );

    const isSandbox = process.env.PAYFAST_MODE !== "live";
    const endpoint = isSandbox
      ? "https://sandbox.payfast.co.za/eng/process"
      : "https://www.payfast.co.za/eng/process";

    res.json({ success: true, paymentData: pfData, endpoint });
  } catch (err) {
    console.error("Buy error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

/* =========================
   ITN
========================= */
router.post("/notify", express.urlencoded({ extended: true }), async (req, res) => {
  res.sendStatus(200);

  const pfData = { ...req.body };

  try {
    const receivedSig = pfData.signature;
    delete pfData.signature;

    const calculatedSig = generateSignature(
      pfData,
      process.env.PAYFAST_PASSPHRASE
    );

    if (calculatedSig !== receivedSig) return;
    if (pfData.payment_status !== "COMPLETE") return;

    const event = await Event.findById(pfData.custom_str1);
    if (!event) return;

    const paid = parseFloat(pfData.amount_gross);
    if (Math.abs(paid - event.price) > 0.01) return;

    const isSandbox = process.env.PAYFAST_MODE !== "live";
    const validateUrl = isSandbox
      ? "https://sandbox.payfast.co.za/eng/query/validate"
      : "https://www.payfast.co.za/eng/query/validate";

    const validateRes = await axios.post(
      validateUrl,
      new URLSearchParams(pfData).toString(),
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    );

    if (!validateRes.data.includes("VALID")) return;

    const qrData = `ticket:${pfData.m_payment_id}:${pfData.email_address}`;
    const qrCode = await QRCode.toDataURL(qrData);

    const ticket = new Ticket({
      event: pfData.custom_str1,
      buyerEmail: pfData.email_address,
      qrCode,
      paymentId: pfData.m_payment_id,
      status: "paid",
    });

    await ticket.save();
    event.ticketsAvailable -= 1;
    await event.save();

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "yourgmail@gmail.com",
        pass: "your-app-password",
      },
    });

    await transporter.sendMail({
      from: "yourgmail@gmail.com",
      to: pfData.email_address,
      subject: `Your Ticket: ${event.title}`,
      text: `Event: ${event.title}`,
      attachments: [
        {
          filename: "ticket-qr.png",
          content: Buffer.from(qrCode.split(",")[1], "base64"),
        },
      ],
    });
  } catch (err) {
    console.error("ITN error:", err);
  }
});

module.exports = router;